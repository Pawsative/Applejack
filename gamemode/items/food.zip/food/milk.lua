--[[
	~ Milk ~
	~ Applejack ~
--]]

ITEM.Name			= "Carton of milk";
ITEM.Cost			= 15;
ITEM.Model			= "models/props_junk/garbage_milkcarton002a.mdl";
ITEM.Store			= true;
ITEM.Plural			= "Cartons of milk";
ITEM.Description	= "A carton of milk which removes 15 hunger.";
ITEM.Hunger			= 20;
ITEM.Base			= "food";
