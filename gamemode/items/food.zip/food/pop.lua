--[[
	~ Pop ~
	~ Applejack ~
--]]

ITEM.Name			= "Can of pop";
ITEM.Cost			= 10;
ITEM.Model			= "models/props_junk/PopCan01a.mdl";
ITEM.Store			= true;
ITEM.Plural			= "Cans of pop";
ITEM.Description	= "A can of pop which removes 15 hunger.";
ITEM.Hunger			= 15;
ITEM.Base			= "food";
