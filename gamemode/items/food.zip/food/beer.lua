--[[
	~ Beer ~
	~ Applejack ~
--]]

ITEM.Name			= "Bottle of Beer";
ITEM.Cost			= 10;
ITEM.Model			= "models/props_junk/garbage_glassbottle002a.mdl";
ITEM.Store			= true;
ITEM.Plural			= "Bottles of beer";
ITEM.Description	= "A bottle of beer which removes 15 hunger.";
ITEM.Hunger			= 15;
ITEM.Base			= "food";
