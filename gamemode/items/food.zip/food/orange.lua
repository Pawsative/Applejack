--[[
	~ Orange ~
	~ Applejack ~
--]]

ITEM.Name			= "Orange";
ITEM.Cost			= 20;
ITEM.Model			= "models/props/cs_italy/orange.mdl";
ITEM.Store			= true;
ITEM.Plural			= "Oranges";
ITEM.Description	= "An orange that removes 25 hunger.";
ITEM.Hunger			= 25;
ITEM.Base			= "food";
