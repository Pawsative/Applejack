--[[
	~ Chinese Takeout ~
	~ Applejack ~
--]]
ITEM.Name			= "Chinese Takeout";
ITEM.Cost			= 50;
ITEM.Model			= "models/props_junk/garbage_takeoutcarton001a.mdl";
ITEM.Store			= true;
ITEM.Plural			= "Chinese Takeouts";
ITEM.Description	= "A chinese takeout which removes 50 hunger.";
ITEM.Hunger			= 50;
ITEM.Base			= "food";
