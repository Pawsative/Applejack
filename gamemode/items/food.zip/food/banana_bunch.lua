--[[
	~ Banana Bunch ~
	~ Applejack ~
--]]

ITEM.Name			= "Banana Bunch";
ITEM.Cost			= 100;
ITEM.Model			= "models/props/cs_italy/bananna_bunch.mdl";
ITEM.Store			= true;
ITEM.Plural			= "Banana Bunches";
ITEM.Description	= "A lot of bananas that remove 75 hunger.";
ITEM.Hunger			= 75;
ITEM.Base			= "food";
