--[[
	~ Banana ~
	~ Applejack ~
--]]

ITEM.Name			= "Banana";
ITEM.Cost			= 20;
ITEM.Model			= "models/props/cs_italy/bananna.mdl";
ITEM.Store			= true;
ITEM.Plural			= "Bananas";
ITEM.Description	= "A banana that removes 25 hunger.";
ITEM.Hunger			= 25;
ITEM.Base			= "food";
