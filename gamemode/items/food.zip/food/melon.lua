--[[
	~ Melon ~
	~ Applejack ~
--]]
ITEM.Name			= "Melon";
ITEM.Cost			= 100;
ITEM.Model			= "models/props_junk/watermelon01.mdl";
ITEM.Store			= true;
ITEM.Plural			= "Melons";
ITEM.Description	= "A melon which removes 75 hunger.";
ITEM.Hunger			= 75;
ITEM.Base			= "food";
