--[[
	~ Preserves ~
	~ Applejack ~
--]]

ITEM.Name			= "Jar of preserves";
ITEM.Cost			= 20;
ITEM.Model			= "models/props_lab/jar01b.mdl";
ITEM.Store			= true;
ITEM.Plural			= "Jars of preserves";
ITEM.Description	= "A jar of preserves which remove 25 hunger.";
ITEM.Hunger			= 25;
ITEM.Base			= "food";
