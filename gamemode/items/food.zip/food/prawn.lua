--[[
	~ Prawn ~
	~ Applejack ~
--]]
ITEM.Name			= "Prawn";
ITEM.Cost			= 25;
ITEM.Model			= "models/Gibs/HGIBS_spine.mdl";
ITEM.Store			= true;
ITEM.Plural			= "Prawns";
ITEM.Description	= "A prawn which removes 30 hunger.";
ITEM.Hunger			= 30;
ITEM.Base			= "food";
