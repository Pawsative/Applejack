--[[
	~ Pickles ~
	~ Applejack ~
--]]

ITEM.Name			= "Pickles";
ITEM.Cost			= 20;
ITEM.Model			= "models/props_lab/cactus.mdl";
ITEM.Store			= true;
ITEM.Plural			= "Pickles";
ITEM.Description	= "Some Pickles which remove 25 hunger.";
ITEM.Hunger			= 25;
ITEM.Base			= "food";
