--[[
	~ Baked Beans ~
	~ Applejack ~
--]]

ITEM.Name			= "Can of Baked Beans";
ITEM.Cost			= 20;
ITEM.Model			= "models/props_junk/garbage_metalcan001a.mdl";
ITEM.Store			= true;
ITEM.Plural			= "Cans of Baked Beans";
ITEM.Description	= "Some baked beans which remove 25 hunger.";
ITEM.Hunger			= 25;
ITEM.Base			= "food";
