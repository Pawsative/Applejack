--[[
	~ Dead Baby ~
	~ Applejack ~
--]]

ITEM.Name			= "Dead Baby";
ITEM.Cost			= 200;
ITEM.Model			= "models/props_c17/doll01.mdl";
ITEM.Store			= false;
ITEM.Plural			= "Dead Babies";
ITEM.Description	= "A tasty dead baby. Removes 100 hunger.";
ITEM.Hunger			= 100;
ITEM.Base			= "food";
